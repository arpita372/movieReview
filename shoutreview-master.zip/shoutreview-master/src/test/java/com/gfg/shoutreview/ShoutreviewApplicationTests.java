package com.gfg.shoutreview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoutreviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
